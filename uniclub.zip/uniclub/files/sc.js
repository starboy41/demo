document.write("Hello world")
console.log("Hello world")

function add(a,b) {
  let c = a+b
  return c
}
// alert(add(4,6))